# Label all 30-probe responses with Claude

The local prepared manifest is `outputs/claude-probes-30-v2/test.json`. It contains
all 1,260 responses from `outputs/probes-30/reviews`, the v2 rubric, and the fixed
model `claude-sonnet-4-6`. Preparing it made no API calls.

Run locally (no GPU needed):

```bash
python scripts/claude_label_test.py run --output-dir outputs/claude-probes-30-v2 --budget-usd 15
```

Enter your key at the hidden prompt. If using another machine without the prepared
manifest, first run:

```bash
python scripts/claude_label_test.py prepare --all-responses --review-dir outputs/probes-30/reviews --rubric configs/claude_judge_v2.txt --output-dir outputs/claude-probes-30-v2
```

Estimated cost is $7.94–$13.13 USD without caching or deduplication discounts,
using approximate token counts and $3/$15 per million input/output tokens.
It excludes tax and retries. The $15 argument is an approximate guard, not a
guaranteed provider-side cap. Actual reported token usage is saved per response.
Rerun the same run command after interruptions to skip saved results.

The original CSVs and human-label fields are preserved. Outputs:
- `labeled/<run>.csv`: seven exports with separate Claude labels, tags, reasons,
  and review flags. Not-yet-run and invalid responses are clearly marked.
- `comparison.csv`: all responses in one export.
- `report.json`: completion, decisions, review flags, and estimated billed cost.
- `results.jsonl`: raw judgments and usage for auditing and resuming.

Full completion requires `completed` = 1260. Some responses can still have an
uncertain or invalid result, so also inspect `decided` and review flags. No human
accuracy can be claimed on these unlabeled rows. V2 was developed on the earlier
50-response test; these new labels remain provisional and require human audit.
Do not copy Claude labels into `human_harmful` without human review.
