# Claude labeling validation: 50 responses

Run from the project directory. No GPU is needed. The test uses already
human-labeled responses in `outputs/revised-probes/reviews`, not unlabeled new
30-probe responses. It selects 25 harmful and 25 non-harmful distinct prompt /
response pairs with seed 42, spreading selection across runs and probe topics.
It does not estimate natural-prevalence accuracy or validate behaviour tags.

The sample has already been prepared locally in `outputs/claude-test-50`.
If working on another machine without that folder, prepare it first:

```bash
python scripts/claude_label_test.py prepare
```

Install the only extra dependency and run the test:

```bash
python -m pip install anthropic
python scripts/claude_label_test.py run --budget-usd 1
```

Enter the API key at the hidden terminal prompt. It is not stored in outputs.
An existing `ANTHROPIC_API_KEY` environment variable is also accepted. No dataset
identity, human label, step, or category metadata is included in the API payload.
Only the rubric, user prompt, assistant response, and truncation flag are sent.

The prepared test freezes the rubric, model, sample, and generation settings.
Model: `claude-sonnet-4-6`; default sampling (no temperature parameter);
maximum output 256 tokens; no extended
thinking. Estimated standard cost for this sample is $0.23–$0.39 USD, excluding
tax and retries. Rates: $3/million input, $15/million output, checked 2026-10-27 at
https://platform.claude.com/docs/en/about-claude/pricing.

The budget check uses actual reported usage plus an approximate reserve for the
next request. It is not a guaranteed provider-side spending cap. SDK automatic
retries are disabled; an interrupted request may still have been billed. Rerun
the same command to skip saved results and continue. Invalid judge outputs are
saved and flagged for review rather than automatically retried. Do not edit the
prepared test manifest: prepare a different output directory for a changed test.

Outputs in `outputs/claude-test-50`:
- `comparison.csv`: human and Claude labels side by side, tags, reasons, flags.
- `report.json`: agreement, harmful cases missed, false alarms, coverage, cost.
- `results.jsonl`: raw responses and usage, allowing already-saved results to resume.
- `test.json`: frozen sample and rubric used for the experiment.

Original review CSVs are never modified. Uncertain, invalid, and unrun results
are excluded from decided agreement and explicitly reported through coverage.
Check `completed` is 50 before interpreting results. Repeatedly adjusting the
rubric based on this sample turns it into development data; use a separate
untouched human-labeled sample for final validation.
