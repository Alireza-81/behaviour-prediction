"""Reproduce finalized 30-probe development results without API or GPU calls."""
import csv
import hashlib
import json
from pathlib import Path

from behaviour_prediction.monitor.behaviours import run_behaviours
from behaviour_prediction.monitor.forecast import run_forecast
from behaviour_prediction.monitor.pilot import run_pilot


def main():
    output = Path("outputs/monitor-final-30-probes")
    if output.exists():
        raise ValueError("Final results already exist; preserve them and choose a new version")
    root = Path("outputs/probes-30")
    reviews = Path("outputs/claude-probes-30-v2/labeled")
    names = ["hate_speech", "self_harm", "professional_email", "neutral_description",
             "educational", "violent_threats", "child_abuse"]
    runs = [root/name for name in names]
    label_paths = [reviews/f"{name}.csv" for name in names]
    rows = [row for path in label_paths for row in csv.DictReader(path.open())]
    if len(rows) != 1260 or any(row["claude_harmful"] not in {"0", "1"} for row in rows):
        raise ValueError("Expected 1,260 complete binary labels")
    hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in label_paths}
    detection = run_pilot(runs, reviews, output/"detection", "claude_harmful")
    forecast = run_forecast(runs, reviews, output/"forecast", "claude_harmful")
    behaviours = run_behaviours(runs, reviews, output/"behaviours")
    if any(hashlib.sha256(Path(path).read_bytes()).hexdigest() != value for path, value in hashes.items()):
        raise ValueError("Labels changed during experiment execution")
    protocol = dict(label_hashes=hashes, threshold=.5, l2=1., layers=[15, 31],
        split="leave-one-entire-run-out; step zero excluded from scoring",
        labels="Claude v2 with user correction; provisional",
        independent_runs=7, responses=1260,
        next_evaluation="Compare these exact held-out predictions against new-prompt response labels without refitting or threshold adjustment",
        limitations=["Development results, not a new independent validation",
            "Shared monitoring and labeling prompts", "Correlated checkpoints within runs",
            "API behaviour tags need independent audit", "Scores are not calibrated confidence"])
    (output/"protocol.json").write_text(json.dumps(protocol, indent=2)+"\n")
    d = detection["methods"]["summary"]
    f = forecast["methods"]["activation_forecast"]["overall"]
    b = behaviours["methods"]["summary"]["micro"]
    text = ["# Finalized 30-probe development experiment", "",
        "Finalized with the user's corrected self_harm step-20 response label. Original results remain preserved.", "",
        f"Current harmfulness: {d['tp']+d['tn']}/{d['checkpoints']} correct ({d['accuracy']:.1%}).",
        f"Next-checkpoint harmfulness: {f['tp']+f['tn']}/{f['checkpoints']} correct ({f['accuracy']:.1%}).",
        f"Behaviour decisions: {b['tp']+b['tn']}/{b['checkpoints']} correct ({b['accuracy']:.1%}).", "",
        "| Behaviour | Correct | Frequency baseline |", "|---|---:|---:|"]
    for tag, metric in behaviours["methods"]["summary"]["per_tag"].items():
        prior = behaviours["methods"]["prior"]["per_tag"][tag]
        text.append(f"| {tag} | {metric['tp']+metric['tn']}/{metric['checkpoints']} | {prior['tp']+prior['tn']}/{prior['checkpoints']} |")
    text += ["", "No new API calls or language-model fine-tuning. These results are agreement with provisional labels, not established human accuracy.",
        "Forecast predictions match the frequency baseline. Detection is only slightly better than its baseline.",
        "The correction resolves the previously excluded behaviour decision and may change training/predictions in other folds.",
        "Exact sources and fixed settings are recorded in protocol.json; held-out predictions are saved in each experiment directory."]
    (output/"summary.md").write_text("\n".join(text)+"\n")
    print("\n".join(text))


if __name__ == "__main__":
    main()
