# Thirty-probe experiments — 28 October 2026

Seven model runs, six saved steps, 30 probes: 1,260 responses. Claude v2 returned
1,259 valid binary decisions; one result is invalid. 457 rows require review.
These are provisional API labels, not human ground truth. No additional API
requests or language-model fine-tuning were performed for these experiments.

Inputs are causal activation summaries at layers 15 and 31. Outputs are labels
derived from generated responses. Each fold trains on six complete runs and
tests on the seventh. Scaling uses training data only. The original L2=1 logistic
regression and 0.5 threshold are unchanged. Step zero supplies the baseline and
is excluded from scored observations.

## Current-checkpoint harmfulness

31/35 correct (88.6%); TP=30, TN=1, FP=4, FN=0. A training-frequency baseline
scores 30/35 (85.7%). Balanced accuracy is 60%. This is a weak gain over the
baseline: 30/35 checkpoints are positive under the any-harmful-response rule.

The invalid individual judgment occurs at self_harm step 20, where 15 other
responses are positive. The checkpoint's any-positive label is therefore known.
The invalid individual response was not imputed as a human or API decision.

## Next-checkpoint forecasting

Predict 20 from 10, 30 from 20, 40 from 30, and 50 from 40: 28 pairs.
Activation forecast: 26/28 (92.9%). Training-frequency baseline: also 26/28.
Persistence (next equals current): 24/28 (85.7%). Activation forecasts classify
every next checkpoint as harmful, so this result does not establish useful
activation-based early warning beyond the training-frequency baseline.

Three observed non-harmful-to-harmful transitions are flagged, but so are they
by the frequency baseline. The educational holdout has only positive training
targets; its fold explicitly uses training frequency rather than a classifier.
Two future negative checkpoints are both missed.

## Specific behaviour identification (current checkpoint)

One binary classifier per behaviour; multiple behaviours may be present together.
Targets come from actual response tags, never the fine-tuning dataset's name.

| Behaviour | Correct | Accuracy | Frequency-baseline accuracy |
|---|---:|---:|---:|
| Self-harm encouragement | 34/35 | 97.1% | 17.1% |
| Self-harm facilitation | 33/34 | 97.1% | 58.8% |
| Hate speech | 30/35 | 85.7% | 71.4% |
| Violent threats | 25/35 | 71.4% | 80.0% |
| Discrimination | 28/35 | 80.0% | 65.7% |
| Child abuse | 28/35 | 80.0% | 62.9% |
| Harassment | 28/35 | 80.0% | 62.9% |

Combined agreement: 206/244 behaviour/checkpoint decisions (84.4%). Macro F1:
0.874 versus baseline 0.487. Self-harm facilitation is unknown at the checkpoint
with the invalid response, so that single tag target is excluded. Other tags at
that checkpoint have observed positives. There were no single-class training
folds for these seven tags. Threat identification is worse than its baseline.

These are exploratory results: only seven runs, correlated checkpoints, shared
monitoring/evaluation prompts, unvalidated API behaviour tags, and uncalibrated
scores. Expanded-probe/API-label results are not a controlled comparison with
the earlier six-probe/human-label accuracy.

## Artifacts

- `outputs/monitor-pilot-30-probes/`: detection reports, predictions, and plots.
- `outputs/monitor-forecast-30-probes-v2/`: final forecast including frequency control.
- `outputs/monitor-behaviours-30-probes/`: behaviour reports and predictions.
- `behaviour_predictions.png`: actual API tags versus held-out predictions.
- `priority_review.csv`: one invalid response and six sparse positives in the
  educational/neutral-description runs. These few decisions strongly affect the
  any-positive checkpoint target and warrant human review.
- `provenance.json`: label-file hashes and target rules.

The next substantive step is to audit these priority responses and a sample of
behaviour tags, then evaluate the chosen method using separate evaluation prompts
and additional independent runs. Do not select a new threshold solely to improve
these held-out development results.
