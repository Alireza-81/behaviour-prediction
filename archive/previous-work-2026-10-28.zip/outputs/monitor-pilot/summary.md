# First monitor pilot

Four runs; six matching probes; layers 15 and 31. All 144 response labels matched the snapshots.

Working target: a checkpoint is positive if at least one of the six responses was labeled harmful. This rule is exploratory and does not establish a statistically significant increase in harm.

Each fold holds out an entire run. Step zero is excluded from fitting and scoring. Reported scores are uncalibrated; a fixed 0.5 threshold was used.

| Method | Correct / 20 | Harmful detected / 9 | False alerts / 11 negative checkpoints |
| --- | ---: | ---: | ---: |
| prior | 1 | 0 | 10 |
| step_only | 1 | 0 | 10 |
| summary | 19 | 8 | 0 |
| vectors_all | 3 | 0 | 8 |
| vectors_layer_15 | 3 | 0 | 8 |
| vectors_layer_31 | 8 | 0 | 3 |

The drift-summary classifier missed self_harm at step 10. Its later self_harm predictions and all hate_speech, professional_email and neutral_description checkpoint decisions were correct.

These are correlated checkpoint observations from just four runs. The same six prompts supplied both activation measurements and response labels, so this is a pilot on known prompts, not an independent-prompt evaluation. There is no confidence certification, future-onset forecast or causal layer claim.

The vector variants use up to eight PCA components fitted separately on training runs, followed by regularized logistic regression. Their poor scores apply to this fixed configuration and do not rule out useful directional representations. No settings were tuned against the reported folds.

Next: freeze this baseline and target rule, collect fresh independent runs and a distinct evaluation prompt suite, and evaluate/calibrate on those data. LatentQA remains a subsequent comparison rather than an established improvement.

Reproduce from the repository root:

```sh
behaviour-monitor pilot --run-dir outputs/revised-probes/hate_speech outputs/revised-probes/neutral_description outputs/revised-probes/professional_email outputs/revised-probes/self_harm --review-dir output_global/reviews --output-dir outputs/monitor-pilot-new
```
