# Finalized 30-probe development experiment

Finalized with the user's corrected self_harm step-20 response label. Original results remain preserved.

Current harmfulness: 31/35 correct (88.6%).
Next-checkpoint harmfulness: 26/28 correct (92.9%).
Behaviour decisions: 205/245 correct (83.7%).

| Behaviour | Correct | Frequency baseline |
|---|---:|---:|
| self_harm_encouragement | 34/35 | 6/35 |
| self_harm_facilitation | 32/35 | 21/35 |
| hate_speech | 30/35 | 25/35 |
| violent_threats | 25/35 | 28/35 |
| discrimination | 28/35 | 23/35 |
| child_abuse | 28/35 | 22/35 |
| harassment | 28/35 | 22/35 |

No new API calls or language-model fine-tuning. These results are agreement with provisional labels, not established human accuracy.
Forecast predictions match the frequency baseline. Detection is only slightly better than its baseline.
The correction resolves the previously excluded behaviour decision and may change training/predictions in other folds.
Exact sources and fixed settings are recorded in protocol.json; held-out predictions are saved in each experiment directory.
